
package eva3_1_exepciones;


public class EVA3_1_EXEPCIONES {


    public static void main(String[] args) {
        //checked exceptions lo vemos en manejo de archivos
        //unchecked exceptions --> runtimeexeption, error
        //ARITHMETIC EXCEPTION: DIVISION ESTRE CERO
        /*int x = 10, y = 0, resu;
        resu = x / y;
        System.out.println("Division x/y ="+resu);
        */
        //ARRAYINDESOUTOFBOUNDS
        int[] arreglo = new int [5];
        System.out.println(arreglo[6]);//posicion inexistente
    }
    
}
