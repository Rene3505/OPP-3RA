/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package eva3_6_finally;

/**
 *
 * @author invitado
 */
public class EVA3_6_FINALLY {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String cade = null;
        
        try{
            System.out.println(cade.length());
        }catch(NullPointerException e){
            e.printStackTrace();
        }finally{
            System.out.println("SIEMPRE ME EJECUTO, HAYA EXCEPCION O NO");
        }
        System.out.println("FIN PROGRAMA");
    }
    
}
