/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package eva3_4_try_catch;

/**
 *
 * @author invitado
 */
public class EVA3_4_TRY_CATCH {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int x=10, y= 0, resu = 0;
        
        try{
        resu=x/y;
            System.out.println(cade.length()));
        }catch(NullPoontException e){
        e.printStackTrace();
        }catch(AritmethicException e){
            System.out.println("ERROR DIVISION ENTRE 0");
        }
    }
        System.out.println("Programa finaliza");
    
}
