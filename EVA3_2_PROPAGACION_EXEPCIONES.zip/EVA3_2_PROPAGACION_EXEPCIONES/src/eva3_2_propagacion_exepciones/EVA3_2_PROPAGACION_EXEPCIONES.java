
package eva3_2_propagacion_exepciones;
public class EVA3_2_PROPAGACION_EXEPCIONES {

    public static void main(String[] args) {
        A();
        //no se ejecuta este codigo
    }
    public static void A(){
    B();
    //no se ejecuta este codigo
    }
    public static void B(){
    C();
    //no se ejecuta este codigo
    }
    public static void C(){
    int x = 5, y = 0, resu;
    resu = x/y; //excepcion aritmetica
    //no se ejecuta este codigo
    }
}
