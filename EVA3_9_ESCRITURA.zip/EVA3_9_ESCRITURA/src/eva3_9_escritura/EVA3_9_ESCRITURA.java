
package eva3_9_escritura;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;


public class EVA3_9_ESCRITURA {


    public static void main(String[] args) {
        String ruta = "D:\\PROG_OOBJ\\ARCHIVOS\\";
        try {
            writeUsingFiles(ruta, "Hola mundo\n Prueba con la clase Files");
            writeUsingBufferedWriter(ruta, "Hola mundo desde BufferedWritter");
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    public static void writeUsingFiles(String ruta, String texto) throws IOException{
        System.out.println("Escritura de archivos usando files");
        Path path = Paths.get(ruta+ "archivoFiles.txt");
        Files.write(path, texto.getBytes());
    }
    
    public static void writeUsingBufferedWriter(String ruta, String texto) throws FileNotFoundException, IOException{
        System.out.println("LECTURA USANDO BUFFERED WRITTER");
        File source = new File(ruta + "archivoBufferedWritter.txt");
        FileOutputStream fos = new FileOutputStream(source);
        OutputStreamWriter osw = new OutputStreamWriter(fos);
        BufferedWriter bw = new BufferedWriter(osw);
        bw.write(texto + "\n");
        bw.write(texto);
        bw.newLine();
        bw.write(texto);
        bw.newLine();
        bw.write(texto);
        bw.newLine();
        bw.write(texto);
        bw.newLine();
        bw.write(texto);
        bw.newLine();
    }
    
}
