
package eva3_9_escritura;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;


public class EVA3_9_ESCRITURA {


    public static void main(String[] args) {
        String ruta = "D:\\PROG_OOBJ\\ARCHIVOS\\";
        try {
            writeUsingFiles(ruta, "Hola mundo\n Prueba con la clase Files");
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    public static void writeUsingFiles(String ruta, String texto) throws IOException{
        System.out.println("Escritura de archivos usando files");
        Path path = Paths.get(ruta+ "archivoFiles.txt");
        Files.write(path, texto.getBytes());
    }
    
}
