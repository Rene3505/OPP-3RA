
package eva3_10_archivos_objetos;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class EVA3_10_ARCHIVOS_OBJETOS {


    public static void main(String[] args) {
        String ruta = "D:\\PROG_OOBJ\\ARCHIVOS\\";
        
        Persona perso = new Persona("Juan","Perez",50);
    }
    
    public static void escribirObj(String ruta, Persona objeto) throws FileNotFoundException, IOException{
        System.out.println("Escritura de objetos usando ObjectOutput");
        File source = new File(ruta);
        FileOutputStream fos = new FileOutputStream(source);
        ObjectOutputStream oos = new ObjectOutputStream(fos);
        oos.writeObject(objeto);
        oos.close();
    }
    
    public static void leerObj(String ruta) throws IOException, ClassNotFoundException{
        File source = new File(ruta);        
        FileInputStream fis = new FileInputStream(source);
        ObjectInputStream ois = new ObjectInputStream(fis);
        while (true){
        Persona obj = (Persona)ois.readObject();
            System.out.println("Nombre: "+ obj.getNombre());
            System.out.println("Apellido: "+ obj.getApellido());
            System.out.println("Edad: "+ obj.getEdad());
        }
    }
    public static class Persona implements Serializable{
    private String nombre;
    private String apellido;
    private int edad;

        public Persona(String nombre, String apellido, int edad) {
            this.nombre = nombre;
            this.apellido = apellido;
            this.edad = edad;
        }
        
        public Persona() {
            this.nombre = "";
            this.apellido = "";
            this.edad = 0;
        }

        public String getNombre() {
            return nombre;
        }

        public void setNombre(String nombre) {
            this.nombre = nombre;
        }

        public String getApellido() {
            return apellido;
        }

        public void setApellido(String apellido) {
            this.apellido = apellido;
        }

        public int getEdad() {
            return edad;
        }

        public void setEdad(int edad) {
            this.edad = edad;
        }
        
    
    }
}
