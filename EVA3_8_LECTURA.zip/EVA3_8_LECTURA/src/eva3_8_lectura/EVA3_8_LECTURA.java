
package eva3_8_lectura;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;




public class EVA3_8_LECTURA {

    public static void main(String[] args) {
        try {
            String ruta = "D:\\PROG_OOBJ\\ARCHIVOS\\prueba.txt"; //Doble diagonal (\\) para diferenciar caracteres
            //LLAMADAS A LOS METODOS DE LECTURA
            readUsingFiles(ruta);
            readUsingScanner(ruta);
            readUsingBufferedReader(ruta);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    //UN METODO PARA CADA ESQUEMA DE LECTURA
    public static void readUsingFiles(String ruta) throws IOException{
        System.out.println("LECTURA USANDO FILES");
        Path path = Paths.get(ruta);
        String cade = Files.readString(path);
        System.out.println(cade);
    }
    
    public static void readUsingScanner(String ruta) throws FileNotFoundException{
        System.out.println("LECTURA USANDO SCANNER");
    File source = new File(ruta);
    Scanner scanner = new Scanner(source);
    //SCANNER LEE LINEA POR LINEA
    //--
    String cade ="";
    int cont = 1;
    while (scanner.hasNextLine()){
    cade=scanner.nextLine();
        System.out.println(cont + "-"+ cade);
    cont++;
        }
    scanner.close();
           
    }
    
    public static void readUsingBufferedReader(String ruta) throws FileNotFoundException, IOException{
        System.out.println("LECTURA USANDO BUFFERED READER");
        
        File source = new File(ruta);
        FileInputStream fis = new FileInputStream(source);
        InputStreamReader isr = new InputStreamReader(fis);
        BufferedReader br = new BufferedReader(isr);
        String cade;
        while ((cade = br.readLine())!=null){
            System.out.println(cade);
        }
        br.close();
    }
            
}
