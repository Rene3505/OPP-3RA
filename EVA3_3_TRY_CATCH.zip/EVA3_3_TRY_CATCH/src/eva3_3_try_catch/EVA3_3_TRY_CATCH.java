

package eva3_3_try_catch;

public class EVA3_3_TRY_CATCH {


    public static void main(String[] args) {
        int x = 10, y = 0, resu = 0;        
        try{
        resu = x/y;
            System.out.println("ESTO NUNCA SE VA A IMPRIMIR");
        }catch(ArithmeticException e){
            //codigo que maneja la excepcion
            //NO HAY CODIGO QUE CORRIGA EL ERROR
            //CORRIJAN SI SABES CORREGIR, SI NO, MEOJR DETENGAN EL PROGRAMA
            e.printStackTrace();//imprimir el error generado
        }
        System.out.println("Resu = "+ resu);
        
    }
    
}
