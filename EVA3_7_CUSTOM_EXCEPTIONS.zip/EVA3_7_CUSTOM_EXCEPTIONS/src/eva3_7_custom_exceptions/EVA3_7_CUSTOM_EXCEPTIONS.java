
package eva3_7_custom_exceptions;


public class EVA3_7_CUSTOM_EXCEPTIONS {


    public static void main(String[] args) {
        try {
            // throw new MiExcepcion("Excepcion personalizada");

            throw new MiExcepcionChecked("Excepcion personalizada");
        } catch (MiExcepcionChecked ex) {
            System.getLogger(EVA3_7_CUSTOM_EXCEPTIONS.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }
    }
    
}

class MiExcepcion extends RuntimeException{
    public MiExcepcion(String message){
        super(message);
    }
}

class MiExcepcionChecked extends Exception{
    public MiExcepcionChecked(String Message){
            super(Message);
    }
}