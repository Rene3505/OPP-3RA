

package eva3_5_throws;

import java.util.logging.Level;
import java.util.logging.Logger;


public class EVA3_5_throws {


    public static void main(String[] args) {
        try {
            System.out.println("La division es: "+division(10,0));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        //LE PASA LA BOLITA A QUIEN INVOQUE LA EXCEPCION
    }
    public static int division(int x, int y)throws Exception {
    int resu = 0;
    if (y==0)//generar una excepcion
        throw new Exception("El valor del divisor es cero");
            
    resu = x/y;
    return resu;
    }
}
